import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Appointment {
    private int id;
    private int patientId;
    private int doctorId;
    private String appointmentDate;

    public Appointment() {
    }

    // Constructors, getters, setters

    // Create appointment
    private void createAppointment(int patientId, int doctorId, String appointmentDate) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO appointments (patient_id, doctor_id, appointment_date) VALUES (?, ?, ?)");
            statement.setInt(1, patientId);
            statement.setInt(2, doctorId);
            statement.setString(3, appointmentDate);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve appointment by ID
    public Appointment retrieveAppointment(int id) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM appointments WHERE id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new Appointment(
                );
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update appointment
    public void updateAppointment(int id, int patientId, String appointmentDate) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE appointments SET patient_id = ?, doctor_id = ?, appointment_date = ? WHERE id = ?");
            statement.setInt(1, patientId);
            statement.setInt(2, doctorId);
            statement.setString(3, appointmentDate);
            statement.setInt(4, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete appointment by ID
    public void deleteAppointment(int id) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("DELETE FROM appointments WHERE id = ?");
            statement.setInt(1, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public JPanel createAppointmentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2, 10, 10)); // Adjusted layout and spacing

        JTextField patientIdField = new JTextField();
        JTextField doctorIdField = new JTextField();
        JTextField appointmentDateField = new JTextField();
        JButton addButton = new JButton("Add Appointment");
        JButton retrieveButton = new JButton("Retrieve Appointment");
        JButton updateButton = new JButton("Update Appointment");
        JButton deleteButton = new JButton("Delete Appointment");

        // Added labels for clarity
        panel.add(new JLabel("Patient ID:"));
        panel.add(patientIdField);
        panel.add(new JLabel("Doctor ID:"));
        panel.add(doctorIdField);
        panel.add(new JLabel("Appointment Date:"));
        panel.add(appointmentDateField);

        // Added a blank label for spacing
        panel.add(new JLabel(""));
        panel.add(addButton);
        panel.add(retrieveButton);
        panel.add(updateButton);
        panel.add(deleteButton);

        addButton.addActionListener(e -> {
            int patientId = Integer.parseInt(patientIdField.getText());
            int doctorId = Integer.parseInt(doctorIdField.getText());
            String appointmentDate = appointmentDateField.getText();
            createAppointment(patientId, doctorId, appointmentDate);
            JOptionPane.showMessageDialog(panel, "Appointment created successfully.");
        });

        retrieveButton.addActionListener(e -> {
            int id = Integer.parseInt(patientIdField.getText()); // Using patient ID for appointment
            Appointment appointment = retrieveAppointment(id);
            if (appointment != null) {
                doctorIdField.setText(String.valueOf(appointment.getDoctorId()));
                appointmentDateField.setText(appointment.getAppointmentDate());
            } else {
                JOptionPane.showMessageDialog(panel, "Appointment not found.");
            }
        });

        updateButton.addActionListener(e -> {
            int patientId = Integer.parseInt(patientIdField.getText()); // Using patient ID for appointment
            int doctorId = Integer.parseInt(doctorIdField.getText());
            String appointmentDate = appointmentDateField.getText();
            updateAppointment(patientId, doctorId, appointmentDate);
            JOptionPane.showMessageDialog(panel, "Appointment updated successfully.");
        });

        deleteButton.addActionListener(e -> {
            int id = Integer.parseInt(patientIdField.getText()); // Using patient ID for appointment
            deleteAppointment(id);
            JOptionPane.showMessageDialog(panel, "Appointment deleted successfully.");
        });

        return panel;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
    }

    // Getter methods for patient ID, doctor ID, and appointment date
    public int getPatientId() {
        return patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }
}

