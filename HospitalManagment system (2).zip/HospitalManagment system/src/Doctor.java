import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Doctor {
    private int id;
    private String name;
    private String specialization;

    public Doctor() {
    }

    // Constructors, getters, setters

    // Create doctor
    private void createDoctor(String name, String specialization) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO doctor (name, specialization) VALUES (?, ?)");
            statement.setString(1, name);
            statement.setString(2, specialization);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve doctor by ID
    public Doctor retrieveDoctor(int id) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM doctor WHERE id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new Doctor(
                );
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update doctor
    public void updateDoctor(int id, String name, String specialization) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE doctor SET name = ?, specialization = ? WHERE id = ?");
            statement.setString(1, name);
            statement.setString(2, specialization);
            statement.setInt(3, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete doctor by ID
    public void deleteDoctor(int id) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("DELETE FROM doctors WHERE id = ?");
            statement.setInt(1, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public JPanel createDoctorPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 10, 10, 10)); // Added some spacing

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField specializationField = new JTextField();
        JButton addButton = new JButton("Add Doctor");
        JButton retrieveButton = new JButton("Retrieve Doctor");
        JButton updateButton = new JButton("Update Doctor");
        JButton deleteButton = new JButton("Delete Doctor");

        // Added labels for clarity
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Specialization:"));
        panel.add(specializationField);

        // Added a blank label for spacing
        panel.add(new JLabel(""));
        panel.add(addButton);
        panel.add(retrieveButton);
        panel.add(updateButton);
        panel.add(deleteButton);

        addButton.addActionListener(e -> {
            String name = nameField.getText();
            String specialization = specializationField.getText();
            createDoctor(name, specialization);
            JOptionPane.showMessageDialog(panel, "Doctor created successfully.");
        });

        retrieveButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            Doctor doctor = retrieveDoctor(id);
            if (doctor != null) {
                nameField.setText(doctor.getName());
                specializationField.setText(doctor.getSpecialization());
            } else {
                JOptionPane.showMessageDialog(panel, "Doctor not found.");
            }
        });

        updateButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String specialization = specializationField.getText();
            updateDoctor(id, name, specialization);
            JOptionPane.showMessageDialog(panel, "Doctor updated successfully.");
        });

        deleteButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            deleteDoctor(id);
            JOptionPane.showMessageDialog(panel, "Doctor deleted successfully.");
        });

        return panel;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital", "root", "Aman1234");
    }

    // Getter methods for name and specialization
    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }
}

