import javax.swing.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("Hospital Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        Patient patient = new Patient();
        Doctor doctor = new Doctor();
        Appointment appointment = new Appointment();

        tabbedPane.addTab("Patients", patient.createPatientPanel());
        tabbedPane.addTab("Doctors", doctor.createDoctorPanel());
        tabbedPane.addTab("Appointments", appointment.createAppointmentPanel());

        add(tabbedPane);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}



