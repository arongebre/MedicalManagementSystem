import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Patient {
    private int id;
    private String name;
    private String phoneNumber;
    private int age;
    private String gender;

    public Patient() {
    }

    // Constructors, getters, setters

    // Create patient
    private void createPatient(String name, String phoneNumber, int age, String gender) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO patients (name, phone_number, age, gender) VALUES (?, ?, ?, ?)");
            statement.setString(1, name);
            statement.setString(2, phoneNumber);
            statement.setInt(3, age);
            statement.setString(4, gender);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve patient by ID
    public Patient retrievePatient(int id) {
        try {
            Connection connection = getConnection(); // Establish a connection to the database
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM patients WHERE id = ?"); // Prepare a SQL statement
            statement.setInt(1, id); // Set the parameter in the SQL statement
            ResultSet resultSet = statement.executeQuery(); // Execute the query and get the result set

            if (resultSet.next()) { // If there is a result
                // Retrieve patient information from the result set
                String name = resultSet.getString("name");
                String phoneNumber = resultSet.getString("phone_number");

                // Create a new Patient object and populate it with the retrieved data
                Patient patient = new Patient();
                patient.setId(id);
                patient.setName(name);
                patient.setPhoneNumber(phoneNumber);



                connection.close(); // Close the connection to the database

                return patient; // Return the Patient object
            }
            connection.close(); // Close the connection to the database
        } catch (SQLException e) {
            e.printStackTrace(); // Print any SQL exceptions that occur
        }
        return null; // Return null if no patient is found or if an exception occurs
    }


    private void setPhoneNumber(String phoneNumber) {
    }

    private void setName(String name) {
    }

    private void setId(int id) {
    }


    // Update patient
    public void updatePatient(int id, String name, String phoneNumber, int age, String gender) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE patients SET name = ?, phone_number = ?, age = ?, gender = ? WHERE id = ?");
            statement.setString(1, name);
            statement.setString(2, phoneNumber);
            statement.setInt(3, age);
            statement.setString(4, gender);
            statement.setInt(5, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete patient by ID
    public void deletePatient(int id) {
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("DELETE FROM patients WHERE id = ?");
            statement.setInt(1, id);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public JPanel createPatientPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(12, 2, 10, 10)); // Added some spacing

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField genderField = new JTextField();
        JButton addButton = new JButton("Add Patient");
        JButton retrieveButton = new JButton("Retrieve Patient");
        JButton updateButton = new JButton("Update Patient");
        JButton deleteButton = new JButton("Delete Patient");

        // Added labels for clarity
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Phone Number:"));
        panel.add(phoneField);
        panel.add(new JLabel("Age:"));
        panel.add(ageField);
        panel.add(new JLabel("Gender:"));
        panel.add(genderField);

        // Added a blank label for spacing
        panel.add(new JLabel(""));
        panel.add(addButton);
        panel.add(retrieveButton);
        panel.add(updateButton);
        panel.add(deleteButton);

        addButton.addActionListener(e -> {
            String name = nameField.getText();
            String phoneNumber = phoneField.getText();
            int age = Integer.parseInt(ageField.getText());
            String gender = genderField.getText();
            createPatient(name, phoneNumber, age, gender);
            JOptionPane.showMessageDialog(panel, "Patient created successfully.");
        });

        retrieveButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            Patient patient = retrievePatient(id);
            if (patient!=null) {
                System.out.println("Aman1");
                nameField.setText(patient.getName());
                phoneField.setText(patient.getPhoneNumber());
                ageField.setText(String.valueOf(patient.getAge()));
                genderField.setText(patient.getGender());
            } else {
                JOptionPane.showMessageDialog(panel, "Patient not found.");
            }
        });

        updateButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String phoneNumber = phoneField.getText();
            int age = Integer.parseInt(ageField.getText());
            String gender = genderField.getText();
            updatePatient(id, name, phoneNumber, age, gender);
            JOptionPane.showMessageDialog(panel, "Patient updated successfully.");
        });

        deleteButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            deletePatient(id);
            JOptionPane.showMessageDialog(panel, "Patient deleted successfully.");
        });

        return panel;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital", "root", "Aman1234");
    }

    // Getter methods for name, phone number, age, and gender
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
}




